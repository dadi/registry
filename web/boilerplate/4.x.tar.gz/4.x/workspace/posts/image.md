---
date: 2015-04-17
title: Look, a post with an image in
author: The DADI Team
---

![A picture](http://52.213.165.8:8001/samples/moose.jpg?width=700&resizeStyle=aspectfit)

This image is loaded using our [DADI CDN](http://docs.dadi.tech/sandbox/cdn/) sandbox.