---
date: 2016-02-17
title: How to serve static assets
author: The DADI Team
---

Anything you put in the `workspace/public` (path configurable in `config/config.development.json`) will be served as a static asset. For example your [robots.txt](/robots.txt), or [CSS file](/styles.css)