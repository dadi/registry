---
date: 2014-04-17
title: We can handle pagination too...
author: The DADI Team
---

This install uses our pagination helper which we have taken from our [Dust.js helpers](https://www.npmjs.com/package/@dadi/dustjs-helpers) package. We also recommend including the [common Dust.js helpers](https://github.com/rodw/common-dustjs-helpers).